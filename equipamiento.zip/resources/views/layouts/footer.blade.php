<div class="footer-left">
    Div. 911 y Videovig. Sección Técnica &copy; {{ date('Y') }}
</div>
